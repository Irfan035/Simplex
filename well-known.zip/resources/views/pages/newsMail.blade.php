<h2>Subscribe Form!</h2> <br><br>

You received an email from : Subscribe <br><br>

User details: <br><br>

Email: {{ $data['email'] }} <br>

Thanks