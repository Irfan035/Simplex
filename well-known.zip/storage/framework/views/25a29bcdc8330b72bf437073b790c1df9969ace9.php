<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
<?php $__env->startSection('content'); ?>
<!--begin::Post-->
<div class="post d-flex flex-column-fluid " id="kt_post">
<!--begin::Container-->
<div id="kt_content_container" class="container">
<div class="row pb-3 pt-2">
    <div class="col-md-6">
            <h1>Contact Form List</h1>
            </div>
        <div class="col-md-6 text-lg-center">
            <a class="btn btn-success" href="<?php echo e(_('contact')); ?>"> Contact Us</a>
        </div>
    
</div>


                      <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                            <?php
                                Session::forget('success');
                            ?>
                        </div>
                      <?php endif; ?>


<table class="p-3 table  table-dark table-striped table-responsive">
  <thead>
   <tr>
    <th >No</th>
    <th>Name</th>
    <th>Email</th>
    <th>Phone</th>
    <th>Subject</th>
    <th>Message</th>
    <th>Action</th>
  </tr>
  <thead>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tbody>
    <tr>
    <td ><?php echo e(++$i); ?></td>
    <td><?php echo e($contact->name); ?></td>
    <td><?php echo e($contact->email); ?></td>
    <td><?php echo e($contact->phone); ?></td>
    <td><?php echo e($contact->subject); ?></td>
    <td><?php echo e($contact->message); ?></td>
    <td><?php echo Form::open(['method' => 'GET','route' => ['destroyContact', $contact->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

        <?php echo Form::close(); ?></td>
  </tr>
  <tbody>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


<?php echo $data->render(); ?>

</div>
</div>
<?php $__env->stopSection(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home3/paradkq1/public_html/simplexoutsourcing/resources/views/admin/contacts.blade.php ENDPATH**/ ?>