<h2>Job Application!</h2> <br><br>

You received an email from : <?php echo e($data['name']); ?> <br><br>

User details: <br><br>

Name: <?php echo e($data['name']); ?><br>
Email: <?php echo e($data['email']); ?> <br>
CNIC:  <?php echo e($data['cnic']); ?><br>
Phone:  <?php echo e($data['phone']); ?><br>
Address: <?php echo e($data['address']); ?><br>
Position Applied: <?php echo e($data['position']); ?> <br>
LinkedIn:  <?php echo e($data['LinkedIn']); ?><br>
How did you hear about us?:  <?php echo e($data['aboutUs']); ?><br>
Upload Your Resume: <?php echo e($data['Resume']); ?> <br>
Available:  <?php echo e($data['available']); ?><br>
Cover Letter:  <?php echo e($data['message']); ?><br><br>

Thanks<?php /**PATH /home3/paradkq1/public_html/simplexoutsourcing/resources/views/pages/careerMail.blade.php ENDPATH**/ ?>