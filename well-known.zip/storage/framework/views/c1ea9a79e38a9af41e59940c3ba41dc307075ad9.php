<h2>Get A Quote!</h2> <br><br>

You received an email from : <?php echo e($data['name']); ?> <br><br>

User details: <br><br>

Name: <?php echo e($data['name']); ?><br>
Email: <?php echo e($data['email']); ?> <br>
Country:  <?php echo e($data['country']); ?><br>
Phone:  <?php echo e($data['phone']); ?><br>
Website/Business: <?php echo e($data['bussiness']); ?><br>
Project Duration: <?php echo e($data['duration']); ?> <br>
Required Resources:  <?php echo e($data['resources']); ?><br>
Best Time to Call You:  <?php echo e($data['callTime']); ?><br>
Message:  <?php echo e($data['message']); ?><br><br>

Thanks<?php /**PATH /home3/paradkq1/public_html/simplexoutsourcing/resources/views/pages/quoteMail.blade.php ENDPATH**/ ?>