<h2>Contact Form!</h2> <br><br>

You received an email from : <?php echo e($data['name']); ?> <br><br>

User details: <br><br>

Name: <?php echo e($data['name']); ?><br>
Email: <?php echo e($data['email']); ?> <br>
Phone:  <?php echo e($data['phone']); ?><br>
Subject:  <?php echo e($data['subject']); ?><br>
Message:  <?php echo e($data['message']); ?><br><br>

Thanks<?php /**PATH /home3/paradkq1/public_html/simplexoutsourcing/resources/views/pages/contactMail.blade.php ENDPATH**/ ?>