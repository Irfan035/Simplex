<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
<?php $__env->startSection('content'); ?>
<!--begin::Post-->
<div class="post d-flex flex-column-fluid " id="kt_post">
<!--begin::Container-->
<div id="kt_content_container" class="container">
<div class="row pb-3 pt-2">
    <div class="col-md-6">
            <h1>Job Applications List</h1>
            </div>
        <div class="col-md-6 text-lg-center">
            <a class="btn btn-success" href="<?php echo e(_('career')); ?>"> Career</a>
        </div>
    
</div>


                      <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                            <?php
                                Session::forget('success');
                            ?>
                        </div>
                      <?php endif; ?>


<div class="table-responsive">
<table class="table  table-dark table-striped">
  <thead>
   <tr>
    <th >No</th>
    <th>Name</th>
    <th>CNIC</th>
    <th>Email</th>
    <th>Phone</th>
    <th>Address</th>
    <th>Position Applied</th>
    <th>LinkedIn</th>
    <th>Hear about us?</th>
    <th>Resume</th>
    <th>Availability</th>
    <th>Cover Letter</th>
    <th>Action</th>
  </tr>
  <thead>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $career): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tbody>
    <tr>
    <td ><?php echo e(++$i); ?></td>
    <td><?php echo e($career->name); ?></td>
    <td><?php echo e($career->cnic); ?></td>
    <td><?php echo e($career->email); ?></td>
    <td><?php echo e($career->phone); ?></td>
    <td><?php echo e($career->address); ?></td>
    <td><?php echo e($career->position); ?></td>
    <td><?php echo e($career->LinkedIn); ?></td>
    <td><?php echo e($career->aboutUs); ?></td>
    <td><a href="<?php echo e($career->Resume); ?>" target="_blank">Check</a></td>
    <td><?php echo e($career->available); ?></td>
    <td><?php echo e($career->message); ?></td>
    <td><?php echo Form::open(['method' => 'GET','route' => ['destroyCareer', $career->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

        <?php echo Form::close(); ?></td>
  </tr>
  <tbody>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>


<?php echo $data->render(); ?>

</div>
</div>
<?php $__env->stopSection(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\simplex\resources\views/admin/careerList.blade.php ENDPATH**/ ?>