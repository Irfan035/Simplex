<h2>Contact Form!</h2> <br><br>

You received an email from : {{ $data['name'] }} <br><br>

User details: <br><br>

Name: {{ $data['name'] }}<br>
Email: {{ $data['email'] }} <br>
Phone:  {{ $data['phone'] }}<br>
Subject:  {{ $data['subject'] }}<br>
Message:  {{ $data['message'] }}<br><br>

Thanks