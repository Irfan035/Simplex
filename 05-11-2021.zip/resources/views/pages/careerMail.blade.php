<h2>Job Application!</h2> <br><br>

You received an email from : {{ $data['name'] }} <br><br>

User details: <br><br>

Name: {{ $data['name'] }}<br>
Email: {{ $data['email'] }} <br>
CNIC:  {{ $data['cnic'] }}<br>
Phone:  {{ $data['phone'] }}<br>
Address: {{ $data['address'] }}<br>
Position Applied: {{ $data['position'] }} <br>
LinkedIn:  {{ $data['LinkedIn'] }}<br>
How did you hear about us?:  {{ $data['aboutUs'] }}<br>
Upload Your Resume: {{ $data['Resume'] }} <br>
Available:  {{ $data['available'] }}<br>
Cover Letter:  {{ $data['message'] }}<br><br>

Thanks