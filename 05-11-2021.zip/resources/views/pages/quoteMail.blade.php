<h2>Get A Quote!</h2> <br><br>

You received an email from : {{ $data['name'] }} <br><br>

User details: <br><br>

Name: {{ $data['name'] }}<br>
Email: {{ $data['email'] }} <br>
Country:  {{ $data['country'] }}<br>
Phone:  {{ $data['phone'] }}<br>
Website/Business: {{ $data['bussiness'] }}<br>
Project Duration: {{ $data['duration'] }} <br>
Required Resources:  {{ $data['resources'] }}<br>
Best Time to Call You:  {{ $data['callTime'] }}<br>
Message:  {{ $data['message'] }}<br><br>

Thanks