<h2>Hey !</h2> <br><br>

You received an email from : <?php echo e($name); ?> <br><br>

User details: <br><br>

Name:  <?php echo e($name); ?><br>
Email:  <?php echo e($email); ?><br>
Phone:  <?php echo e($phone); ?><br>
Subject:  <?php echo e($subject); ?><br>
Message:  <?php echo $subject; ?><br><br>

Thanks<?php /**PATH /home3/paradkq1/public_html/simplexoutsourcing/resources/views/pages/contactMail.blade.php ENDPATH**/ ?>