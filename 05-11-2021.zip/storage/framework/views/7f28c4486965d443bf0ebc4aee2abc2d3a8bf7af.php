
<?php echo $__env->make('welcome.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- ==============contact-setion-one============== -->

<section class="contact-section-one bg-light pt-5 pb-5">
    <div class="container text-center">
            <h1 class="font-weight-bold blueColor display-2  pt-5">Contact Us<span class="OrangColor">!</span></h1>
            <p>We are here to help you in all business domains.</p>
            <br><a class="nav-btn-sm" href="<?php echo e(_('get-a-quote')); ?>">Get Started</a> <br>
    </div>
</section>

<!-- ==============section-two============ -->
<section class="contact-section-two pb-4">
   <div class="container">
       <div class="row">
           <div class="col-md-4">
               <div class="contact-card p-3 rounded text-center">
               <i class="fas fa-phone-alt"></i>
               <h4>Phone</h4>
               <p>+1 (718) 395-6788</p>
               </div>
           </div>
           <div class="col-md-4">
               <div class="contact-card p-3 rounded text-center">
               <i class="far fa-envelope"></i>
               <h4>Email</h4>
               <p>Info@simplexoutsourcing.com</p>
               </div>
           </div>
           <div class="col-md-4">
               <div class="contact-card p-3 rounded text-center">
               <i class="fas fa-map-marker-alt"></i>
               <h4>Location</h4>
               <p>898 Bay Ridge Avenue, Brooklyn, New York, USA</p>
               </div>
           </div>
       </div>
     
      
   </div>
</section>
<!-- ==============contact-section-three============ -->
<section class="contact-section-three pt-5 pb-5" >
    <div class="container">
    
            <div class="row">
                <div class="col-md-6">
                    <h1 class="text-white font-weight-bold display-5">Let's Start Conversation<i class="fas fa-square outsourceo-dot"></i></h1>
                    <div class="p-2">
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                            <?php
                                Session::forget('success');
                            ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <form id="contact-form" class="form-group pt-3 needs-validation" method="POST" action="<?php echo e(route('contactForm')); ?>" novalidate>
                    <?php echo csrf_field(); ?>
                         <!--Grid row-->
                        <div class="form-row">

                        <!--Grid column-->
                        <div class="col-md-6">
                        <input type="text" id="name" name="name" id="validationCustom01" placeholder="Your name" value="<?php echo e(old('name')); ?>"  class="form-control" required>
                        <div class="valid-feedback">
                            Looks good!
                        </div>
                        <?php if($errors->has('name')): ?>
                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        <?php endif; ?>
                        </div>
                        <!--Grid column-->

                        <!--Grid column-->
                        <div class="col-md-6">
                        <input type="email" id="email" name="email" id="validationCustom02" placeholder="Your email" class="form-control" value="<?php echo e(old('email')); ?>" required>
                        <div class="valid-feedback">
                            Looks good!
                        </div>
                        <?php if($errors->has('email')): ?>
                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                        <?php endif; ?>
                        </div>
                        <!--Grid column-->

                        </div>
                        <!--Grid form-row-->

                        <div class="form-row">

                        <!--Grid column-->
                        <div class="col-md-6">
                        <input type="text" id="phone" name="phone" id="validationCustom03" placeholder="Phone" value="<?php echo e(old('phone')); ?>"  class="form-control" required>
                        <div class="valid-feedback">
                            Looks good!
                        </div>
                        <?php if($errors->has('phone')): ?>
                            <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                        <?php endif; ?>
                        </div>
                        <!--Grid column-->

                        <!--Grid column-->
                        <div class="col-md-6">
                        <input type="text" id="subject" name="subject" id="validationCustom02" placeholder="Subject" class="form-control" required>
                        <div class="valid-feedback">
                            Looks good!
                        </div>
                        <?php if($errors->has('subject')): ?>
                            <span class="text-danger"><?php echo e($errors->first('subject')); ?></span>
                        <?php endif; ?>
                        </div>
                        <!--Grid column-->

                        </div>
                        <!--Grid form-row-->

                        <!--Grid form-row--> 
                        <div class="form-row">

                        <!--Grid column-->
                        <div class="col-md-12">
                        <textarea type="text" id="message" name="message" id="validationCustom04" placeholder="Your message" rows="2"  class="form-control md-textarea" required></textarea>
                        <div class="valid-feedback">
                            Looks good!
                        </div>
                        <?php if($errors->has('message')): ?>
                            <span class="text-danger"><?php echo e($errors->first('message')); ?></span>
                        <?php endif; ?>
                        </div>
                        </div>
                        <!--Grid form-row--> <br>
                        <button class="btn btn-white btn-submit" type="submit">Submit</button>

                    </form>
                </div>
                <div class="col-md-6"></div>
            </div>
    </div>
</section>



<?php echo $__env->make('welcome.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home3/paradkq1/public_html/simplexoutsourcing/resources/views/pages/contact.blade.php ENDPATH**/ ?>