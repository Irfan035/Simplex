<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
<?php $__env->startSection('content'); ?>
<!--begin::Post-->
<div class="post d-flex flex-column-fluid " id="kt_post">
<!--begin::Container-->
<div id="kt_content_container" class="container">
<div class="row pb-2">
        <div class="col-lg-6">
            <h2> Show User</h2>
        </div>
        <div class="col-lg-6">
            <a class="btn btn-primary" href="<?php echo e(_('users')); ?>"> Back</a>
        </div>
</div>


<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 shadow p-5 m-3">
        <div class="form-group">
           <strong class="text-dark display-6">Name: </strong>
            <?php echo e($user->name); ?>

        </div>
        <div class="form-group">
          <strong class="text-dark display-6">Email: </strong>
            <?php echo e($user->email); ?> 
        </div>
        <div class="form-group">
           
            <strong class="text-dark display-6">Roles: </strong>
            <?php if(!empty($user->getRoleNames())): ?>
                <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="badge badge-success"><?php echo e($v); ?></label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
        </div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\simplex\resources\views/users/show.blade.php ENDPATH**/ ?>