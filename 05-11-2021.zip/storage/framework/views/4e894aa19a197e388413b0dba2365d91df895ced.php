
<?php echo $__env->make('welcome.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- ==============Location-setion-one============== -->

<section class="about-section-one" style='background-image: url("media/bg/banner-about.jpg");'>
    <div class="container">
      <h1 class="text-white font-weight-bold text-center display-3 pt-4">Our Locations<i class="fas fa-square outsourceo-dot"></i></h1>
      <p class="text-white text-center">Our strength is in our unparalleled commitment to care for your business and your changing business needs.</p>
    </div>
</section>

<!-- ==============section-two============ -->
<section class="Locations-section-two pt-5 pb-5">
   <div class="container pt-5">
      <h4 class="text-white text-center"><span class="bgOrangColor rounded pl-2 pr-2">Locations Outsourceo</span></h4>
      <h1 class="blueColor font-weight-bold text-center">Countery<i class="fas fa-square outsourceo-dot"></i></h1>
      <div class="row">
        <div class="col-md-4 text-center pt-3 pb-5 facts">
          <div class="pt-3 p-2">
          <img src="media/pages/facts1-about.png" alt="simplex outsourceing client">
            <h1 class="text-center font-weight-bold blueColor pt-4">Location One<i class="fas fa-square outsourceo-dot-sm"></i></h1>
            <p>Our vertical solutions expertise allows your business to streamline workflow, and increase productivity.</p>
            <p><a href="http://" class="text-dark">Learn More <i class="fas fa-caret-right"></i></a></p>
          </div>
        </div>
        <div class="col-md-4 text-center pt-3 pb-5 facts">
          <div class="pt-3 p-2">
          <img src="media/pages/facts1-about.png" alt="simplex outsourceing client">
          <h1 class="text-center font-weight-bold blueColor pt-4">Location Two<i class="fas fa-square outsourceo-dot-sm"></i></h1>
            <p>Our vertical solutions expertise allows your business to streamline workflow, and increase productivity.</p>
            <p><a href="http://" class="text-dark">Learn More <i class="fas fa-caret-right"></i></a></p>
          </div>
        </div>
        <div class="col-md-4 text-center pt-3 pb-5 facts">
          <div class="pt-3 p-2">
          <img src="media/pages/facts1-about.png" alt="simplex outsourceing client">
          <h1 class="text-center font-weight-bold blueColor pt-4">Location Three<i class="fas fa-square outsourceo-dot-sm"></i></h1>
            <p>Our vertical solutions expertise allows your business to streamline workflow, and increase productivity.</p>
            <p><a href="http://" class="text-dark">Learn More <i class="fas fa-caret-right"></i></a></p>
          </div>
        </div>
      </div>
   </div>
</section>
<!-- ==============Locations-section-three============ -->
<section class="Locations-section-three pt-5 pb-5">
<div class="container-fluid">
    <div class="map-responsive">
    <iframe src="https://www.google.com/maps/embed/v1/place?key=AIzaSyA0s1a7phLN0iaD6-UE7m4qP-z21pH0eSc&q=Eiffel+Tower+Paris+France" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
</div>
</section>

<!-- ==============Locations-section-four============ -->
<section class="about-section-four pt-5 pb-5" style='background-image: url("media/bg/red_dots.png");'>
  <div class="container text-center pt-5 pb-5 mt-5 mb-5">
    <h1 class="p-3 font-weight-bold">Here to Help Your Every Business Need<i class="fas fa-square outsourceo-dot"></i></h1>
    <p>We focus on the IT solutions, so you can focus on your business.</p> <p> See what we can do for you today!</p>
    <br><a class="nav-btn-sm" href="#">Get Started</a>
  </div>
</section>



<?php echo $__env->make('welcome.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\simplex\resources\views/pages/locations.blade.php ENDPATH**/ ?>